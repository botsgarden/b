const {Service, Failure, Success, Wrapper, fetch} = require('./pico')
const url = require("url")
const qs = require('querystring')
const path = require('path')

class isJavaScript extends Wrapper {}
class isMarkDown extends Wrapper {}
class isText extends Wrapper {}
class isSomethingElse extends Wrapper {}
class isJson extends Wrapper {}




class GitHubLikeClient {
  constructor({baseUri, token}, ...features) {
    this.baseUri = baseUri;
    this.credentials = token !== null && token.length > 0 ? "token" + ' ' + token : null;
    this.headers = {
      "Content-Type": "application/json",
      "Accept": "application/vnd.github.v3.full+json",
      "Authorization": this.credentials
    };
    return Object.assign(this, ...features);
  }

  callAPI({method, path, data}) {
    let urlTocall = url.parse(this.baseUri+path)
    return fetch({
      protocol: urlTocall.protocol.slice(0, -1), // remove ":"
      host: urlTocall.hostname,
      port: urlTocall.port,
      method: method,
      path: urlTocall.path,      
      headers:  this.headers,
      data: data!==null ? JSON.stringify(data) : null
    }).then(data => {
      return JSON.parse(data)
    }).catch(error => error)
  }

  getData({path}) {
    return this.callAPI({method:'GET', path, data:null});
  }

  deleteData({path}) {
    return this.callAPI({method:'DELETE', path, data:null});
  }

  postData({path, data}) {
    return this.callAPI({method:'POST', path, data});
  }

  putData({path, data}) {
    return this.callAPI({method:'PUT', path, data});
  }
}

let dvcsCli = new GitHubLikeClient({
  baseUri: process.env.DVCS_API,
  token: process.env.DVCS_TOKEN
})

let port = process.env.PORT || 8080;

let bob = new Service({})

let checkToken = token => 
  token == process.env.SLACK_TOKEN
  ? Success.of(token)
  : Failure.of("😡 Bad token")

let checkRequest = data => checkToken(data.token).when({
  Failure: error => error,
  Success: token => {
    if(data.user_id=="USLACKBOT") {
      return Failure.of("🤖 doesn't answer to 🤖") // dont't answer to itself
    } else {
      let botTrigger = process.env.BOT_TRIGGER 
      if(data.text.includes(botTrigger)) {
        return Success.of(token)
      } else {
        return Failure.of(`👋 You must say ${botTrigger} to talk to the bot`)
      }
    }
  }
})

let checkContent = contentPath => {
  if(path.parse(contentPath).ext == ".js") { return isJavaScript.of(contentPath) }
  if(path.parse(contentPath).ext == ".md") { return isMarkDown.of(contentPath) }
  if(path.parse(contentPath).ext == ".txt") { return isText.of(contentPath) }
  if(path.parse(contentPath).ext == ".json") { return isJson.of(contentPath) }  
  return isSomethingElse.of(contentPath)
}
  
let answer = data => {
  let slackUrl = url.parse(process.env.SLACK_URL)   
  return fetch({
    protocol: slackUrl.protocol.slice(0, -1), // remove ":"
    host: slackUrl.hostname,
    port: slackUrl.port,
    method: "POST",
    path: slackUrl.path,      
    headers:  {"Content-Type": "application/json; charset=utf-8"},
    data: data!==null ? JSON.stringify(data) : null
  }).then(data => {
    return JSON.parse(data)
  }).catch(error => error)
}

let tokenize = (content) => {
  return content.split(" ").map((item)=>item.trim()).filter((item)=>item!=='')
}

bob.post({uri:`/api/receive`, f: (request, response) => {
  let data = qs.parse(request.body)
  console.log(data)
  checkRequest(data).when({
    Failure: error => console.log(error),
    Success: token => {
      let user = data.user_name
      let message = data.text
      // CONTENT_PATH=k33g/bob/contents/db.js
      dvcsCli.getData({path:`/repos/${process.env.CONTENT_PATH}/contents/db.json`}).then(dvcsResponse => {
        console.log("❤️", dvcsResponse)
        let jsonDb = JSON.parse(new Buffer(dvcsResponse.content, dvcsResponse.encoding).toString("ascii"))

        console.log("😜 jsonDb", jsonDb)

        let tokens  = new Set(tokenize(message))

        console.log("😝 tokens", tokens)

        let contents = jsonDb.filter( // length sould play on precision
          item => {
            let keywords = new Set(item.keywords.split(";"))
            return [...tokens].filter(x => keywords.has(x)).length >=2 // 2 keywords min
          }
        )

        contents.forEach(
          record => {
            dvcsCli.getData({path:`/repos/${process.env.CONTENT_PATH}/contents/${record.content}`}).then(dvcsResponse => {
              
              let content = new Buffer(dvcsResponse.content, dvcsResponse.encoding).toString("utf8")
              
              checkContent(record.content).when({
                isJavaScript: (contentPath) => {
                  let func = eval(content)
                  let resfunc = func(user, message)

                  console.log("🤖", resfunc, resfunc instanceof Promise)
                  console.log("😍", message)

                  if(resfunc instanceof Promise) {
                    resfunc.then(data => {
                      answer(data)
                    }).catch(error => {
                      answer(error)
                    })
                  } else {
                    answer(resfunc)
                  }

                },
                isText: (contentPath) => {
                  answer({text: `Hi @${user}, the answer is:\n` + content})
                },
                isMarkDown: (contentPath) => {
                  answer({text: `Hi @${user}, the answer is:\n` + content , "mrkdwn": true})
                },
                isJson: (contentPath) => {
                  let transformMenu = (content) => {
                    return JSON.parse(content).map(item => {
                      return {
                        title: item.keywords, value: item.content, short: false
                      }
                    })
                  }

                  let jsonContent = path.parse(contentPath).name == "db"
                    ? transformMenu(content)
                    : JSON.parse(content)

                  answer({text: `Hi @${user}, the answer is:\n`, attachments: [
                    {
                      fields: jsonContent
                    }
                  ]})                  
                },
                _: (contentPath) => {
                  answer({text: `Hi @${user}, the answer is:\n` + content})
                }
              })

              /*
              if(path.parse(record.content).ext == ".js") {
                let func = eval(content)
                answer({text: `Hi @${user}, the answer is:\n` + func(user, message)})
              } else {
                answer({text: `Hi @${user}, the answer is:\n` + content})
              }*/

            })
          }
        )
      }).catch(err => {
        console.log(err)
      })      
    }
  })
  response.writeHead(200)
  response.end();
}})

bob.start({port: port}, res => {
  res.when({
    Failure: error => console.log("😡 Houston? We have a problem!"),
    Success: port => {
      console.log(`🌍 bob the 🤖 is listening on ${port}`)
      answer({text: `👋 Hello 🌍 ! Bob the 🤖 in the place`})      
    }
  })
})
