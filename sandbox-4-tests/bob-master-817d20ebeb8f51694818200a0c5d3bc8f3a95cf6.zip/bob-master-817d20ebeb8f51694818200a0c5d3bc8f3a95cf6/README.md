# Bob

A little bot experiment

## Add Slack outgoing webhook

So you can speak to bob

- add the url of bob: http://bob-the-bot.cleverapps.io/api/receive
- copy the token somewhere `PtbMWGQxCqoxPSFIAoY7EkHk`
- Add `SLACK_TOKEN=PtbMWGQxCqoxPSFIAoY7EkHk` to environment variables

## Add Slack incoming webhook

So bob can answer you

- copy the webhook url: https://hooks.slack.com/services/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
- add SLACK_URL=https://hooks.slack.com/services/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

## Clever ☁️ slide

> Application id: `app_7c1b5d1a-ba26-4dc0-b904-30743dc48f17`

```shell
BOT_TRIGGER=@bob
CONTENT_PATH=k33g/bob
DVCS_API=https://customers-tickets.cleverapps.io/api/v3
DVCS_TOKEN=f020f28326de076652b5dca5dab7fe11f66cf5c6
PORT=8080
SLACK_TOKEN=xgbaIqruk2UW6u06ngQyQRi6
SLACK_URL=https://hooks.slack.com/services/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
```

- `CONTENT_PATH` is the path of the repository to store keywords and answers
- `DVCS_TOKEN`: you have to generate a web token to get authorization from the DVCS


## Remark

```
git+ssh://git@push-par-clevercloud-customers.services.clever-cloud.com/app_7c1b5d1a-ba26-4dc0-b904-30743dc48f17.git
```

> Currently, if you want to add data to the "facts base" of **Bob**, it's here: [https://customers-tickets.cleverapps.io/k33g/bob](https://customers-tickets.cleverapps.io/k33g/bob) (ask to be member of the project)

## Contributing

- be nice ❤️
- use emoji in commit messages:
  - https://gitmoji.carloscuesta.me/
  - https://www.webpagefx.com/tools/emoji-cheat-sheet/
- if you want to add a feature, to fix a 🐞, ...:
  - start a merge request with a little commit explaining what you whant to do

🎉 Have fun




